# Proof of Utility Index (PoUI) – MVP v1

PoUI ranks cryptocurrencies based on real-world utility.
